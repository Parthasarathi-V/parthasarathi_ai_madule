print(ZeroDivisionError)
