number_list = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

#it is used only for calculator sometimes only  using other    
def for_calc(query):
    
    #declarations
    val1 = []
    #excute
    splited = query.split()
    for i in range(len(splited)):
        value = ''
        x = 0
        for word in splited[i]:
            if word in number_list:
                value = value + word
        if value != '':
            val1.append(int(value))
    return val1;

import tables

def for_table(query, name):
    pos = []
    query = query.split()
    for i in range(len(query)):
        for letter in query[i]:
            if letter in number_list:
                pos.append(int(i))  
    print(pos)
    ext = ['st', 'nd', 'rd', 'th', ',']
    pos = set(pos)
    table = []
    times = 10

    if name == "table":
        name = "multiplication table"

    for i in pos:

        for ex in ext:
            if ex in query[i]: 
                table.append(int(query[i].replace(f'{ex}', '')))

        if query[i-1] == 'upto':
            times = int(query[i])
        
        elif name == "tables":
            table = [int(query[i]) for i in pos]
        
        else:
            print("Invalid")
        
    print(table)
        
    #tables.table(table, times, name)
